// File: src/components/PreviewPane.js
import React from 'react';

const PreviewPane = ({ models }) => {
  return (
    <div>
      <h2>Models Preview</h2>
      <textarea
        value={JSON.stringify(models, null, 2)}
        readOnly
        style={{ width: '100%', height: '300px' }}
      />
    </div>
  );
};

export default PreviewPane;