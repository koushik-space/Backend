// File: src/components/FeatureSelector.js
import React from 'react';

const FeatureSelector = ({ features, setFeatures }) => {
  return (
    <div>
      <h2>Select Features</h2>
      {Object.entries(features).map(([key, val]) => (
        <label key={key}>
          <input
            type="checkbox"
            checked={val}
            onChange={(e) => setFeatures({ ...features, [key]: e.target.checked })}
          />{' '}
          {key}
        </label>
      ))}
    </div>
  );
};

export default FeatureSelector;