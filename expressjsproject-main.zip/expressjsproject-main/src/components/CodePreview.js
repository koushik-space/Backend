import React from "react";

const generateModelCode = (model) => {
  const fields = model.fields
    .map((f) => {
      const required = f.required ? ", required: true" : "";
      const def = f.defaultValue ? `, default: '${f.defaultValue}'` : "";
      return `  ${f.name}: { type: ${f.type}${required}${def} }`;
    })
    .join(",\n");

  return `const mongoose = require('mongoose');

const ${model.modelName}Schema = new mongoose.Schema({
${fields}
}, { timestamps: true });

module.exports = mongoose.model('${model.modelName}', ${model.modelName}Schema);`;
};

const generateControllerCode = (modelName) => {
  const lc = modelName.toLowerCase();
  return `const ${modelName} = require('../models/${modelName}');

// CREATE
exports.create${modelName} = async (req, res) => {
  try {
    const doc = await ${modelName}.create(req.body);
    res.status(201).json(doc);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// READ
exports.getAll${modelName}s = async (req, res) => {
  const data = await ${modelName}.find();
  res.json(data);
};

// UPDATE
exports.update${modelName} = async (req, res) => {
  try {
    const updated = await ${modelName}.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.json(updated);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// DELETE
exports.delete${modelName} = async (req, res) => {
  await ${modelName}.findByIdAndDelete(req.params.id);
  res.json({ success: true });
};`;
};

const generateJwtMiddleware = () => {
  return `const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) return res.status(401).json({ error: 'No token provided' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ error: 'Invalid token' });
  }
};

module.exports = authMiddleware;`;
};

const generateErrorUtils = () => {
  return `exports.handleError = (res, error, status = 400) => {
  res.status(status).json({ error: error.message || error });
};`;
};

const generateCustomMiddleware = () => {
  return `const logMiddleware = (req, res, next) => {
  console.log(\`\${req.method} \${req.originalUrl}\`);
  next();
};

module.exports = logMiddleware;`;
};

const generateRouteCode = (modelName) => {
  const lc = modelName.toLowerCase();
  return `const express = require('express');
const router = express.Router();
const ${lc}Controller = require('../controllers/${modelName}');

// Routes
router.post('/', ${lc}Controller.create${modelName});
router.get('/', ${lc}Controller.getAll${modelName}s);
router.put('/:id', ${lc}Controller.update${modelName});
router.delete('/:id', ${lc}Controller.delete${modelName});

module.exports = router;`;
};

const generateEntryPoint = (models) => {
  const routeImports = models
    .map((m) => `app.use('/api/${m.modelName.toLowerCase()}', require('./routes/${m.modelName}.routes'));`)
    .join('\n');

  return `const express = require('express');
const mongoose = require('mongoose');
require('dotenv').config();
const app = express();

app.use(express.json());

// Routes
${routeImports}

const PORT = process.env.PORT || 5000;
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB connected');
  app.listen(PORT, () => console.log(\`Server running on port \${PORT}\`));
}).catch((err) => console.error(err));`;
};

const CodePreview = ({ models, features }) => {
  if (!models.length) return null;

  return (
    <div style={{ marginTop: "2rem" }}>
      <h2>📦 Generated Code Preview</h2>

      {features.jwtAuth && (
        <>
          <h3>middleware/auth.middleware.js</h3>
          <pre>{generateJwtMiddleware()}</pre>
        </>
      )}
      {features.errorUtils && (
        <>
          <h3>utils/error.utils.js</h3>
          <pre>{generateErrorUtils()}</pre>
        </>
      )}
      {features.customMiddleware && (
        <>
          <h3>middleware/logger.middleware.js</h3>
          <pre>{generateCustomMiddleware()}</pre>
        </>
      )}

      {models.map((model, i) => (
        <div key={i} style={{ marginTop: "1rem" }}>
          <h3>{model.modelName} Files</h3>
          {features.mongoose && (
            <>
              <h4>models/{model.modelName}.model.js</h4>
              <pre>{generateModelCode(model)}</pre>
            </>
          )}
          {features.controllers && (
            <>
              <h4>controllers/{model.modelName}.controller.js</h4>
              <pre>{generateControllerCode(model.modelName)}</pre>
            </>
          )}
          {features.routes && (
            <>
              <h4>routes/{model.modelName}.routes.js</h4>
              <pre>{generateRouteCode(model.modelName)}</pre>
            </>
          )}
        </div>
      ))}

      <h3>index.js</h3>
      <pre>{generateEntryPoint(models)}</pre>
    </div>
  );
};

export default CodePreview;