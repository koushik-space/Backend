// ✅ Enhanced React App with Advanced Model Generation Capability

// File: src/components/ModelBuilder.js
import React from 'react';

const DATA_TYPES = [
  'String',
  'Number',
  'Boolean',
  'Date',
  'Buffer',
  'ObjectId',
  'Array',
  'Mixed',
  'Map'
];

const ModelBuilder = ({ modelName, setModelName, fields, setFields, handleAddField, handleFieldChange, handleAddModel }) => {
  return (
    <div>
      <h2>Define a Model</h2>
      <input
        placeholder="Model Name (e.g. User)"
        value={modelName}
        onChange={(e) => setModelName(e.target.value)}
      />
      {fields.map((field, index) => (
        <div key={index}>
          <input
            placeholder="Field Name"
            value={field.name}
            onChange={(e) => handleFieldChange(index, 'name', e.target.value)}
          />
          <select
            value={field.type}
            onChange={(e) => handleFieldChange(index, 'type', e.target.value)}
          >
            {DATA_TYPES.map((type) => (
              <option key={type} value={type}>{type}</option>
            ))}
          </select>
          <input
            placeholder="Default"
            value={field.defaultValue}
            onChange={(e) => handleFieldChange(index, 'defaultValue', e.target.value)}
          />
          <label>
            <input
              type="checkbox"
              checked={field.required}
              onChange={(e) => handleFieldChange(index, 'required', e.target.checked)}
            /> Required
          </label>
        </div>
      ))}
      <button onClick={handleAddField}>+ Add Field</button>
      <button onClick={handleAddModel}>Add Model</button>
    </div>
  );
};

export default ModelBuilder;