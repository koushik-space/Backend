// File: src/App.js
import React, { useState } from 'react';
import ModelBuilder from './components/ModelBuilder';
import FeatureSelector from './components/FeatureSelector';
import PreviewPane from './components/PreviewPane';
import CodePreview from './components/CodePreview';

const App = () => {
  const [models, setModels] = useState([]);
  const [modelName, setModelName] = useState('');
  const [fields, setFields] = useState([{ name: '', type: 'String', required: false, defaultValue: '' }]);
  const [features, setFeatures] = useState({
    crud: true,
    controllers: true,
    routes: true,
    mongoose: true,
    jwtAuth: false,
    errorUtils: true,
    customMiddleware: false,
    advancedExample: true
  });

  const handleAddField = () => {
    setFields([...fields, { name: '', type: 'String', required: false, defaultValue: '' }]);
  };

  const handleFieldChange = (index, key, value) => {
    const updated = [...fields];
    updated[index][key] = value;
    setFields(updated);
  };

  const handleAddModel = () => {
    if (!modelName) return;
    setModels([...models, { modelName, fields }]);
    setModelName('');
    setFields([{ name: '', type: 'String', required: false, defaultValue: '' }]);
  };

  return (
    <div style={{ padding: '1rem' }}>
      <h1>Express.js Backend Generator</h1>
      <ModelBuilder
        modelName={modelName}
        setModelName={setModelName}
        fields={fields}
        setFields={setFields}
        handleAddField={handleAddField}
        handleFieldChange={handleFieldChange}
        handleAddModel={handleAddModel}
      />
      <FeatureSelector
        features={features}
        setFeatures={setFeatures}
      />
      <PreviewPane models={models} />
      <CodePreview models={models} features={features} />
    </div>
  );
};

export default App;
